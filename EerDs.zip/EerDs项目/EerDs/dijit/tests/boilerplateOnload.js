// Part of boilerplate.js but need to put it in a separate file for IE9, so it doesn't run until dojo has finished
// loading and require is defined
require(["dojo/domReady!"], boilerplateOnLoad);
