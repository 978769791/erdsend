define(
({
	loadingState: "Memuatkan...",
	errorState: "Maaf, terjadi kesalahan"
})
);

