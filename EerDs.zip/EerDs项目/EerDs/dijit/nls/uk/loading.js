define(
({
	loadingState: "Завантаження...",
	errorState: "Сталася помилка"
})
);
