define(
({
	loadingState: "טעינה...‏",
	errorState: "אירעה שגיאה"
})
);
