define(
({
	buttonOk: "確定",
	buttonCancel: "取消",
	buttonSave: "儲存",
	itemClose: "關閉"
})
);
